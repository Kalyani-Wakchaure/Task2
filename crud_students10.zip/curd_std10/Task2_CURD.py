#connect to the mysql database
import mysql.connector
try:
    conn= mysql.connector.connect(host = "127.0.0.1", user = "root",
                                  password = "Cdac@2022", database = "crud_python")
    mycursor = conn.cursor()
    print("connection established")
except:
    print("connection error") 
#Create the database

#mycursor.execute("create database crud_python")
#conn.commit()
#print("database created")

# Create a table
'''mycursor.execute(
    """ create table std2(
    Id integer primary key,
    name varchar(50) not null,
    city varchar(50), age integer, pincode integer)""")
conn.commit()
print("Table is created")

#insert new record into student table


mycursor.execute(
    """ insert into std2 values
    (1,"kalyani","pune",28,412105),
    (2,"Pranav","Delhi",23,110038),
    (3,"komal","pune",26,411013),
    (4,"Latika","Akole",31,422601),
    (5,"monika","Sangamner",29,422605)  """)
conn.commit()
print("rows are inserted")'''

#Read the data
mycursor.execute("select * from std2")
myresult = mycursor.fetchall()
#print(myresult)
for x in myresult:
    print(x)   #print(x[0])

#update record
'''mycursor.execute("update std2 set age = 20 where id = 2")
conn.commit()
print("updated")'''

#delete data from table
'''mycursor.execute("delete from std2 where id = 4")
conn.commit()
print("deleted")'''
